Title of the project:
Transparent recruitment process analysis

Introduce yourself and share with your peers your background and any experience you have with data science. (1 mark)

Hi!
My name is Alex and I'm studying data science. My previous experience in data science was a project with HR-data in our medium-business IT company. We've done anonymous research of our employee and their relations with managers, analysis of recruitment process and several other staff. I've never get in touch with big data, but our samples was pretty difficult and interesting to work for. My dream and my project for 2019 is transparent recruitment process analysis. From the very first marketing-touch with company (in social networks, media or special project) to the day of hiring. All the data like UTM or private feedback about recruiter should be carefully stored and analyzed.


Based on the videos and the reading material, how would you define a data scientist and data science? (3 marks)

Data scientists is the people who analyze the data, help organizations to measure their efficiency, and help to make right data-based decisions.
Data science is what data scientist do <3
In other words, data science is a way to use scientific methods,  systems, processes and algorithms to extract insights from data.


As discussed in the videos and the reading material, data science can be applied to problems across different industries. What industry are you passionate about and would like to pursue a data science career in? (1 mark)

My dream is marketing-like data-driven approach in IT-recruitment and transparent process of analysis of digital-marketing to hiring efficiency.


Based on the videos and the reading material, what are the ten main components of a report that would be delivered at the end of a data science project? (5 marks)

- Cover page
- Table of content
- Introductory section
- Literature review
- Methodology section
- Result section
- Discussion section
- Conclusion
- References
- Appendices
